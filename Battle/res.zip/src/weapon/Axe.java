package weapon;

/**
 * The class represents weapon weapon.Axe.
 */
public class Axe extends Weapon {
  /**
   * Calls the super constructor.
   */
  public Axe() {
    super(6, 10, "Axe");
  }
}
