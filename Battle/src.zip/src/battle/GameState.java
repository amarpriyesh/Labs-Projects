package battle;

/**
 * Enum values for game state.
 */
public enum GameState {
  SETUP, PLAYING, DRAW, P1WIN, P2WIN
}
