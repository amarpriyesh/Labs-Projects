package weapon;

import battle.Arena;

/**
 * Represents weapon.Weapon.
 */
public class Weapon implements WeaponI {
  //RandGen obj = new RandGen();

  private int damage;
  private final int lowerBound;
  private final int upperBound;
  private final String name;

  /**
   * Constructor taking bounds.
   * @param lowerBound lb.
   * @param upperBound ub.
   * @param name name.
   */
  public Weapon(int lowerBound, int upperBound, String name) {
    this.lowerBound = lowerBound;
    this.upperBound = upperBound;
    this.name = name;
  }

  /**
   * return Damage.
   * @return damage.
   */
  public int getDamage() {
    return damage;
  }

  /**
   * Returns the damage value.
   * @return damage.
   */
  @Override
  public int generateDamage() {
    this.damage = Arena.OBJ.nextInt(lowerBound, upperBound);
    return this.damage;
  }

  /**
   * returns name of the weapon.
   * @return name.
   */
  public String getName() {
    return name;
  }
}
