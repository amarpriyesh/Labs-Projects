package weapon;

/**
 * Represents sword katana.
 */
public class Katana extends Sword {

  /**
   * constructor.
   */
  public Katana() {
    super(4, 6, "Katana");
  }
}
