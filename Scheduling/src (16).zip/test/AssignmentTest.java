import static org.junit.Assert.assertEquals;

import assignments.AlphabeticalSchedulingStrategy;
import assignments.AssignedSchedulingStrategy;
import assignments.Assignment;
import assignments.AssignmentList;
import assignments.DeadlineSchedulingStrategy;
import assignments.DifficultySchedulingStrategy;

import org.junit.Test;

import java.time.LocalDate;

/** Class that tests the tasks. */
public class AssignmentTest {


  /** Testing constructor and toString(). */
  @Test
  public void testConstructor() {
    Assignment t1 = new Assignment("buy beer");
    t1.setDeadline(11, 1, 2022);
    t1.setStart(11,1,2022);
    Assignment t2 = new Assignment("review module materials");
    t2.setDeadline(11, 5, 2022);
    t2.setStart(11,1,2022);
   // assertEquals("task 2, starting " + now + ", ending 2025-03-04", t2.toString());
    Assignment t3 = new Assignment("take quiz");
    t3.setDeadline(11, 5, 2022);
    t3.setStart(11,5,2022);
    Assignment t4 = new Assignment("complete self evaluation for Lab 8");
    t4.setDeadline(11, 11, 2022);
    t4.setStart(11,9,2022);
    Assignment t5 = new Assignment("turn in CS5010 Module 9 Lab");
    t5.setDeadline(11, 7, 2022);
    t5.setStart(11,2,2022);

    AssignmentList obj = new AssignmentList();
    //AssignmentList obj2 = new AssignmentList();

    obj.add(t1);
    obj.add(t2);
    obj.add(t3);
    obj.add(t4);
    obj.add(t5);
    obj.scheduleAssignments(new AssignedSchedulingStrategy());

    System.out.println(obj.toString());

/*    obj.scheduleAssignments(new AlphabeticalSchedulingStrategy());
    System.out.println(obj.toString());
    obj.scheduleAssignments(new AssignedSchedulingStrategy());
    System.out.println(obj.toString());
    obj.scheduleAssignments(new DeadlineSchedulingStrategy());
    System.out.println(obj.toString());
    obj.scheduleAssignments(new DifficultySchedulingStrategy());
    System.out.println(obj.toString());*/



  }
}
