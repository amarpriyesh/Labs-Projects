package lookandsay;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.math.BigInteger;
import java.util.NoSuchElementException;


/**
 * Represents test class to test the methods and functionality of LookAndSayIterator.
 */
public class LookAndSayTest {

  /**
   * Does basic test.
   */
  @Test
  public void testBasic() {
    RIterator<BigInteger> it = new LookAndSayIterator();
    assertTrue(it.hasNext());
    assertEquals(new BigInteger("1"), it.next());
  }

  /**
   * Tests if has next is there.
   */
  @Test
  public void testNext() {
    RIterator<BigInteger> it = new LookAndSayIterator(new BigInteger("1"));




    assertEquals(1,it.next().intValue());
    assertEquals(11,it.next().intValue());
    assertEquals(21,it.next().intValue());




  }

  /**
   * The test throws o such element exception if the int value exceeds the end value.
   */
  @Test(expected = NoSuchElementException.class)
  public void testNext1() {
    RIterator<BigInteger> it = new LookAndSayIterator(new BigInteger("31"),
            new BigInteger("100"));
    assertEquals(31,it.next().intValue());
    assertEquals(1311,it.next().intValue());
    assertEquals(111321,it.next().intValue());
    assertEquals(31131211,it.next().intValue());


  }

}
