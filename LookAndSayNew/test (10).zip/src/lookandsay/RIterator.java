package lookandsay;

import java.util.Iterator;

public interface RIterator<T>  extends Iterator<T> {
  boolean hasPrevious();
  T prev();
}
