package lookandsay;
import org.junit.Test;

import java.math.BigInteger;

import lookandsay.LookAndSayIterator;
import lookandsay.RIterator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class LookAndSayTest {

  @Test
  public void testBasic() {
    RIterator<BigInteger> it = new LookAndSayIterator();
    assertTrue(it.hasNext());
    assertEquals(new BigInteger("1"), it.next());
  }

  @Test
  public void testNext() {
    RIterator<BigInteger> it = new LookAndSayIterator(new BigInteger("1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111"));



    System.out.println(it.next());
    System.out.println(it.next());
    System.out.println(it.prev());




  }

  @Test
  public void testNext1() {
    RIterator<BigInteger> it = new LookAndSayIterator(new BigInteger("31 "));

    System.out.println(it.next());

    System.out.println(it.next());
    System.out.println(it.next());
    System.out.println(it.next());
    System.out.println(it.next());
    System.out.println(it.next());
    System.out.println(it.next());
    System.out.println(it.next());
    System.out.println(it.next());
    System.out.println(it.next());
    System.out.println(it.next());
    System.out.println(it.next());
    System.out.println(it.prev());
    System.out.println(it.prev());
    System.out.println(it.prev());
    System.out.println(it.prev());
    System.out.println(it.prev());
    System.out.println(it.prev());
    System.out.println(it.prev());
    System.out.println(it.prev());
    System.out.println(it.prev());
    System.out.println(it.prev());
    System.out.println(it.prev());
    System.out.println(it.prev());
    System.out.println(it.prev());



  }

}
