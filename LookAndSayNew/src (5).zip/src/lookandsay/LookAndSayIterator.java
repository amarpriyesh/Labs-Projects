package lookandsay;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;

public class LookAndSayIterator implements RIterator<BigInteger> {

  private static final BigInteger DEFAULT_SEED = new BigInteger("1");
  private static final BigInteger DEFAULT_END = new BigInteger("9".repeat(100));

  private final BigInteger end;
  private BigInteger curr;
  List<String> nextList = new ArrayList<>();
  List<String> currList = new ArrayList<>();
  List<String> prevList = new ArrayList<>();
  int count = 0;
  public LookAndSayIterator(BigInteger seed, BigInteger end) {
    // TODO: validation
    if ( seed.compareTo(new BigInteger("0"))<=0 || seed.compareTo(end)>0  || seed.toString().contains("0") || seed.toString().contains("-") ||  end.toString().contains("-")) {
      throw new IllegalArgumentException("Invalid seed");
    }

    this.end = end;
    this.curr = seed;

  for (int i =0; i<curr.toString().length();i++) {
    currList.add(String.valueOf(curr.toString().charAt(i)));
  }
    //throw new IllegalArgumentException(seed.toString()+"end"+end.toString());
  }

  public LookAndSayIterator(BigInteger seed) {
    this(seed, DEFAULT_END);
  }

  public LookAndSayIterator() {
    this(DEFAULT_SEED, DEFAULT_END);
  }

  @Override
  public boolean hasPrevious() {
    return (curr.toString().length() % 2 == 0) &&  (getPrev().compareTo(end) <= 0);
  }

  @Override
  public BigInteger prev() {
    if (!hasPrevious()) {
      throw new NoSuchElementException("No previous number present");
    }
    getPrev();
    String str = "";
    //int count = prevList.size() -1;
    for (String item:prevList
         ) {
      str = item + str;

    }
    curr = new BigInteger(str);
    currList = new ArrayList<>();
    for (int i =0; i<curr.toString().length();i++) {
      currList.add(String.valueOf(curr.toString().charAt(i)));
    }
    return curr;
  }


  private BigInteger getPrev() {
    prevList = new ArrayList<>();


    String str ="";
    for (int i = currList.size() -1; i>=0;i-=2) {
      int count = Integer.parseInt(currList.get(i-1));
    while (count >0) {
      str =currList.get(i) +str;
      prevList.add(currList.get(i));
      count--;
    }
    }

    return  new BigInteger(str);
  }

  @Override
  public boolean hasNext() {
    return getNext().compareTo(end) <= 0;
  }


  private BigInteger getNext() {
    nextList = new ArrayList<>();
    // compute next value based on current, and return it, WITHOUT mutating anything

    String str ="";
    int count = 1;
    for (int i = 0; i<curr.toString().length();i++) {

      if (i != (curr.toString().length() -1) ) {
        if (curr.toString().charAt(i) == curr.toString().charAt(i + 1)) {
count++;

        }
        else{
          nextList.add(String.valueOf(count));
          nextList.add(String.valueOf(curr.toString().charAt(i)));
          str=str+String.valueOf(count)+String.valueOf(curr.toString().charAt(i));
          count =1;
        }
      }
      else {
        nextList.add(String.valueOf(count));
        nextList.add(String.valueOf(curr.toString().charAt(i)));
          str=str+String.valueOf(count)+String.valueOf(curr.toString().charAt(i));


      }
    }
String  str2 = "";
    for (String item:nextList
    ) {
      str2 = str2 + item;
    }
    return new BigInteger(str2);

  }

  @Override
  public BigInteger next() {
    if (count==0) {
      count++;
      return curr;
    }
    currList = new ArrayList<>();
    if (!hasNext()) {
      throw new NoSuchElementException("No next number present");
    }
    curr = getNext();
    for (int i =0; i<curr.toString().length();i++) {
      currList.add(String.valueOf(curr.toString().charAt(i)));
    }
    return curr;
  }


}
