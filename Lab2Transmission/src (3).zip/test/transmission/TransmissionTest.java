package transmission;

import org.junit.Before;
import org.junit.Test;



import static org.junit.Assert.assertEquals;


public class TransmissionTest {
  Transmission threshhold;

  @Before
  public void setUp() {
    threshhold = new AutomaticTransmission(15, 30, 45, 60, 75);
    for ( int i = 0; i < 43 ; i++){
      threshhold.increaseSpeed();
    }
  }

  @Test
  public void testIncreaseSpeed() {
  }

  @Test
  public void decreaseSpeed() {
  }

  @Test
  public void getSpeed() {
  }

  @Test
  public void getGear() {
  }

  @Test
  public void testToString() {
    assertEquals("Transmission (speed = 43, gear = 3)",threshhold.toString());
  }
}