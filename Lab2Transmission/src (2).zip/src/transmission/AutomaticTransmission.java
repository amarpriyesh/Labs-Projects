package transmission;

public class AutomaticTransmission implements Transmission {

  final private int speed1;
  final private  int speed2;
  final private int speed3;
  final private int speed4;
  final private int speed5;
  int  speedInitial;

  public AutomaticTransmission( int speed1, int speed2, int speed3, int speed4, int speed5) {
    this.speed1 = speed1;
    this.speed2 = speed2;
    this.speed3 = speed3;
    this.speed4 = speed4;
    this.speed5 = speed5;
    this.speedInitial = 0;


  }

  /**
   * Increases the speed by 1 MPH updating the gear appropriately.
   */
  @Override
  public void increaseSpeed() {

  this.speedInitial = this.speedInitial + 1;
  }

  /**
   * Decreases the speed by 1 MPH updating the gear appropriately.
   *
   * @throws IllegalStateException if called would cause the speed to go below 0
   */
  @Override
  public void decreaseSpeed() throws IllegalStateException {
    this.speedInitial = this.speedInitial - 1;

  }

  /**
   * Gets the speed of this Transmission.
   *
   * @return the speed
   */
  @Override
  public int getSpeed() {
    return this.speedInitial;
  }

  /**
   * Gets the gear of this Transmission.
   *
   * @return the gear
   */
  @Override
  public int getGear() {
    int gear;
    if (this.speedInitial == 0){
     return gear = 0;
    }
    else if ( this.speedInitial > 0 && this.speedInitial <= this.speed1){
     return gear = 1;
    }
    else if (this.speedInitial > this.speed1 && this.speedInitial <= this.speed2){
     return gear = 2;
    }
    else if (this.speedInitial > this.speed2 && this.speedInitial <= this.speed3){
     return gear = 3;
    }
    else if (this.speedInitial > this.speed3 && this.speedInitial <= this.speed4){
    return  gear = 4;
    }
    else if (this.speedInitial > this.speed5 ){
    return  gear = 5;
    }
    return 0;
  }

  @Override
  public String toString() {
    return String.format("Transmission (speed = %d, gear = %d)",
            this.speedInitial,
            this.getGear());
  }
  @Override
  public boolean equals(Object o) {

    if (this == o) {
      return true;
    }

    if (!(o instanceof Transmission)) {
      return false;
    }

    Transmission that = (Transmission) o;
    return this.toString().equals(that.toString());


  }

  @Override
  public int hashCode() {
    return this.toString().hashCode();
  }
}

