package polynomial;
import java.util.Comparator;
public interface ListOfTerm {
  ListOfTerm addTerm(int coefficient,int power);
  int getCoefficient(int power);
  Term retTerm();
  double evaluate(double x);
  ListOfTerm add(Polynomial other);
  public Term getTerm();
  public ListOfTerm getRest() ;
  public int getDegree();
}
