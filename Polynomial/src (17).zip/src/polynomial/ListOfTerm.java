package polynomial;
import java.util.Comparator;
public interface ListOfTerm {
  ListOfTerm addTerm(int coefficient,int power);
  int getCoefficient(int power);
  Term retTerm();
  double evaluate(double x);
  Polynomial add(Polynomial other);
  public Term getTerm();
  public ListOfTerm getRest() ;
  public int getDegree();

  int chkDegree(int acc);

  String toStringHelp(StringBuilder s);
}
