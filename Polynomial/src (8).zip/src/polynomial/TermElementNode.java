package polynomial;

public class TermElementNode implements ListOfTerm{

  protected  Term term;
  private ListOfTerm rest;
  public TermElementNode(Term term, ListOfTerm rest) {
    if (rest == null) {
     rest = new TermEmptyNode();
    }
 this.term = term;
 this.rest = rest;
  }


  @Override
  public ListOfTerm addTerm(int coefficient, int degree) {
    if (degree <= 0) {
      throw new IllegalArgumentException("Power can't be negative");
    }

    if (degree == this.term.getDegree()){
      this.term = new Term(this.term.getCoefficient()+coefficient,degree);
    }
    else{
      rest = rest.addTerm(coefficient,degree);
      }


 return this;
  }

  @Override
  public int getCoefficient(int power) {
    if (power == this.term.getDegree()){
      return this.term.getCoefficient();
    }
    else{
      return rest.getCoefficient(power);
    }
  }

  public Term retTerm() {
    return this.term;
  }

  @Override
  public double evaluate(double x) {
    double eval = this.term.getCoefficient() * Math.pow(x,this.term.getDegree());
    return eval + rest.evaluate(x);
  }

  @Override
  public ListOfTerm add(Polynomial other) {
    ListOfTerm t;
    t = ((PolynomialImpl) other).head;
    while(t.getTerm() != null) {

  int a =  t.getTerm().getCoefficient();
   int b = t.getTerm().getDegree();
      System.out.println(a+"here is the value"+b); //TODO
   this.addTerm(a, b);
   t = t.getRest();

 }
    return this;
  }

  @Override
  public  String toString() {
    return this.term.toString()+" "+rest.toString();
  }
  public Term getTerm() {
    return this.term;
  }
  public ListOfTerm getRest() {
    return this.rest;
  }


  public int chkDegree(int acc) {
    if (acc < this.getTerm().getDegree()) {
      acc = this.getTerm().getDegree();
    }

    return rest.chkDegree(acc);
  }

  @Override
  public int getDegree() {
    int acc = term.getDegree();
    return chkDegree(acc);
  }

  @Override
  public boolean equals(Object o) {
    if (o instanceof ListOfTerm) {
      ListOfTerm t = (ListOfTerm) o;
      System.out.println(this.toString() + "  " + o.toString() + this.toString().equals(t.toString()));
      return this.toString().equals(t.toString())  && rest.toString().equals(t.toString());
    }
    return false;
  }
}

