package polynomial;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;


/**
 * Represents the test class to test different methods and validations to class polynomial.
 */
public class PolynomialTest {
  Polynomial pol;

  /**
   * sets up a an empty polynomial object or a polynomial with different terms.
   * @throws Exception if the format of the string is not correct.
   */
  @Before
  public void setUp() throws Exception {
    pol = new PolynomialImpl();
  }

  /**
   * Tests if the polynomial has the same value after adding different polynomials.
   */
  @Test
  public void add() {
    Polynomial poly1 = new PolynomialImpl("+3x^4 +2x^5 -5 -20x^4 +11x^1");
    Polynomial poly2 = new PolynomialImpl("4x^1");
    Polynomial poly3 = new PolynomialImpl("2x^5 -17x^4 +15x^1 -5");

    assertTrue(poly3.isSame(poly2.add(poly1)));

  }

  /**
   * Adds various terms to teh empty polynomila and asserts if the right coefficient could be
   * produced.
   */
  @Test
  public void addTerm() {
    //pol.addTerm(3,2);
    pol.addTerm(4, 1);
    pol.addTerm(-5, 3);
    pol.addTerm(5, 3);
    pol.addTerm(8, 2);
    pol.addTerm(-8, -0);
    assertEquals(8, pol.getCoefficient(2));

  }

  /**
   * The below method asserts if we are getting right to string values from the polynomial.
   */
  @Test
  public void testToString() {
    Polynomial poly1 = new PolynomialImpl("2x^5 +17x^1 -3x^3");
    assertEquals(poly1.toString(),"2x^5 -3x^3 +17x^1");
  }

  /**
   * The below method asserts equality of the two polynomials.
   */
  @Test
  public void isSame() {
    Polynomial poly1 = new PolynomialImpl("2 +4x^1");

    Polynomial poly2 = new PolynomialImpl("4x^1 +2");

    assertTrue(poly2.isSame(poly1));
  }

  /**
   * The method evaluates the value of the polynomial and checks if the value is right.
   */
  @Test
  public void evaluate() {
    pol.addTerm(3, 1);
    assertEquals(6,(int)pol.evaluate(2));
  }

  /**
   * The method asserts if we are getting right coefficient of a given term with the degree.
   */
  @Test
  public void getCoefficient() {
    Polynomial poly1 = new PolynomialImpl("4x^1 +2");
    assertEquals(4,poly1.getCoefficient(1));
  }

  /**
   * The method tests if Illegal Argument exception is thrown if we try to create an invalid
   * polynomial.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testValidPoly() {
    Polynomial poly1 = new PolynomialImpl("-5x^1 -3x^-202 +2x^1");

  }

  /**
   * Asserts if  the maximum degree of the polynomial is a correct value.
   */
  @Test
  public void getDegree() {
    Polynomial poly1 = new PolynomialImpl("-5x^1 -3x^202 +2x^1");
    assertEquals(202,poly1.getDegree());
  }
}