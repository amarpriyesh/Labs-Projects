package polynomial;

import org.junit.Before;
import org.junit.Test;

import java.sql.SQLOutput;

import static org.junit.Assert.*;

public class PolynomialTest {
Polynomial pol;
  @Before
  public void setUp() throws Exception {
    pol = new PolynomialImpl();
  }

  @Test
  public void add() {
    Polynomial poly1 = new PolynomialImpl("+3x^4 -2x^5 -5 -2x^4 +11x^1");
    pol.addTerm(4,1);
    //System.out.println(pol.add(poly1).getHead().toString());

  }

  @Test
  public void addTerm() {
    //pol.addTerm(3,2);
    pol.addTerm(4,1);
    pol.addTerm(-5,3);
    pol.addTerm(5,3);
    pol.addTerm(8,2);
    pol.addTerm(-8,0);
    assertEquals(8,pol.getCoefficient(2));

   //System.out.println(pol.getHead().toString());
  }

  @Test
  public void test() {
    Polynomial poly1 = new PolynomialImpl("+3x^4 -2x^5 -5 -2x^4 +11x^1");
    //System.out.println(poly1.getHead().toString());
  }
  @Test
  public void isSame() {
    Polynomial poly1 = new PolynomialImpl("4x^1");
    pol.addTerm(4,1);
    assertTrue(pol.isSame(poly1));
  }

  @Test
  public void evaluate() {
    pol.addTerm(3,1);
    System.out.println(pol.evaluate(2));
    System.out.println(pol.toString());
  }

  @Test
  public void getCoefficient() {
    Polynomial poly1 = new PolynomialImpl();
    Polynomial poly2 = new PolynomialImpl();
    System.out.println(poly1.isSame(poly2));
  }

  @Test
  public void getDegree() {
    Polynomial poly1 = new PolynomialImpl("+3x^4 +88x^265 -2x^5 -5 -2x^4 +11x^1");
    System.out.println(poly1.getDegree());
  }
}