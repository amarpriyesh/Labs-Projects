package polynomial;

/**
 * The interface houses methods to perform operations on union data type of polynomial.
 */
public interface ListOfTerm {

  /**
   * The below method helps adding a term to the polynomial.
   * @param coefficient represents coefficient of the term.
   * @param power represents power of the polynomial.
   * @return returns list of terms.
   */
  ListOfTerm addTerm(int coefficient, int power);

  int getCoefficient(int power);

  Term retTerm();

  double evaluate(double x);

  Polynomial add(Polynomial other);

  Term getTerm();

  ListOfTerm getRest();

  int getDegree();

  int chkDegree(int acc);

  boolean equalHelper(ListOfTerm t);

  String toStringHelp(StringBuilder s);
}
