package polynomial;

import org.junit.Before;
import org.junit.Test;


import static org.junit.Assert.*;

public class PolynomialTest {
  Polynomial pol;

  @Before
  public void setUp() throws Exception {
    pol = new PolynomialImpl();
  }

  @Test
  public void add() {
    Polynomial poly1 = new PolynomialImpl("+3x^4 +2x^5 -5 -20x^4 +11x^1");
    Polynomial poly2 = new PolynomialImpl("4x^1");
    Polynomial poly3 = new PolynomialImpl("2x^5 -17x^4 +15x^1 -5");

   assertTrue(poly3.isSame(poly2.add(poly1)));

  }

  @Test
  public void addTerm() {
    //pol.addTerm(3,2);
    pol.addTerm(4, 1);
    pol.addTerm(-5, 3);
    pol.addTerm(5, 3);
    pol.addTerm(8, 2);
    pol.addTerm(-8, -0);
    assertEquals(8, pol.getCoefficient(2));

    //System.out.println(pol.getHead().toString());
  }

  @Test
  public void test() {
    Polynomial poly1 = new PolynomialImpl("2x^5 +17x^1 -3x^3");
    assertEquals(poly1.toString(),"2x^5 -3x^3 +17x^1");
  }

  @Test
  public void isSame() {
    Polynomial poly1 = new PolynomialImpl("2 +4x^1");

    Polynomial poly2 = new PolynomialImpl("4x^1 +2");

    assertTrue(poly2.isSame(poly1));
  }

  @Test
  public void evaluate() {
    pol.addTerm(3, 1);
    assertEquals(6,(int)pol.evaluate(2));
  }

  @Test
  public void getCoefficient() {
    Polynomial poly1 = new PolynomialImpl("4x^1 +2");
    assertEquals(4,poly1.getCoefficient(1));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidPoly() {
    Polynomial poly1 = new PolynomialImpl("-5x^1 -3x^-202 +2x^1");

  }

  @Test
  public void getDegree() {
    Polynomial poly1 = new PolynomialImpl("-5x^1 -3x^202 +2x^1");
    assertEquals(202,poly1.getDegree());
  }
}